<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/comparative-features-table/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/comparative-features-table/comparative-features-table.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/comparative-features-table/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/comparative-features-table/custom-styles/custom-styles.php';