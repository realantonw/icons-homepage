<?php

require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-tabs/functions.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-tabs/advanced-tabs.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-tabs/advanced-tab.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-tabs/options-map/map.php';
require_once BRIDGE_CORE_SHORTCODES_PATH.'/advanced-tabs/custom-styles/custom-styles.php';